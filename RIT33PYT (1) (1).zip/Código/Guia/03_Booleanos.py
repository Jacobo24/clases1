"""
Comparaci�n entre dos entradas

Se aborda la noci�n de tipo (probar con 4 y 10)
"""

numero1 = input("Introduzca un primer n�mero: ")
numero2 = input("Introduzca un segundo n�mero: ")

# Realiza la comparaci�n
comparacion = numero1 < numero2

print(numero1, "<", numero2, ":", comparacion)

