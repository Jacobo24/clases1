"""
Comparacion entre dos datos introducidos

Abordamos la noci�n de tipo (intentar con 4 y 10)
"""

numero1 = input("Introduzca un primer n�mero: ")
numero2 = input("Introduzca un segundo n�mero: ")

# Hacer la comparaci�n
comparacion = numero1 < numero2

print(numero1, "<", numero2, ":", comparacion)

