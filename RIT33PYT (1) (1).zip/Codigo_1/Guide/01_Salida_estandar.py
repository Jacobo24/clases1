"""
Demostración de la utilización de la salida standard

El ejemplo más básico de programa en Python.
"""

print("Hello World!")

