"""
Módulo que sirve solo para iniciar el juego
"""

from juego import jugar

if __name__ == "__main__":
    jugar()

