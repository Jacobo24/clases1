"""
Demostración de la utilización de la entrada standard

El programa solicita introducir un dato y la visualización en un segundo momento
"""

# Pedimos el ataque
datoIntroducido = input("Introduzca cualquier cosa: ")

# Mostramos este ataque (varias visualizaciones, separadas por " ")
print("Ha introducido:", datoIntroducido)

